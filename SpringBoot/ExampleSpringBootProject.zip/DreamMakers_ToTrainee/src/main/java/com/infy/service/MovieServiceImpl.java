package com.infy.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.MovieDAO;
import com.infy.model.Movie;
import com.infy.validator.Validator;

@Service(value="movieService")
public class MovieServiceImpl implements MovieService {
	
	@Autowired
	private MovieDAO dao;
	
	public String addMovie(Movie movie) throws Exception{
		
		Validator.validate(movie);
		
		return dao.addMovie(movie);
		
	}

	public List<Movie> getMovies(String directorName) throws Exception{

		List<Movie> mList = dao.getMovies();
		
		List<Movie> filteredM = mList.stream().filter(m ->{
			
			return m.getDirector().getDirectorName().equals(directorName);
			
		}).collect(Collectors.toList());
		
		return filteredM;
		
	}
}
