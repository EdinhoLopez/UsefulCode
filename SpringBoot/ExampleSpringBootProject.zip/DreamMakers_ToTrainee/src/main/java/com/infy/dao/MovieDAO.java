package com.infy.dao;

import java.util.List;

import com.infy.model.Movie;


public interface MovieDAO {

	public String addMovie(Movie movie) throws Exception;

	public List<Movie> getMovies() throws Exception;
}
