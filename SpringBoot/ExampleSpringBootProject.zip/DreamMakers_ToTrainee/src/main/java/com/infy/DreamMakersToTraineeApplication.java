package com.infy;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Director;
import com.infy.model.Movie;
import com.infy.service.MovieService;

@SpringBootApplication
public class DreamMakersToTraineeApplication implements CommandLineRunner {
	
	@Autowired
	MovieService movieService;
	
	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(DreamMakersToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		addMovie();
		getMovies();

	}

	public void addMovie() {
		try{
			Movie movie=new Movie();
			movie.setMovieId("M1001");
			movie.setMovieName("Home Alone");
			movie.setReleasedIn(LocalDate.of(1990, 05, 24));
			movie.setLanguage("English");
			movie.setRevenueInDollars(1990);
			
			Director director=new Director();
			director.setDirectorId("D101");
			director.setDirectorName("Chris Columbus");
			director.setBornIn(1958);
			movie.setDirector(director);
			String id=movieService.addMovie(movie);
			System.out.println(environment.getProperty("UserInterface.MOVIE_ADDED_SUCCESS")+ id);
			
		}catch(Exception e){
			System.out.println(environment.getProperty(e.getMessage()));
		}
		

	}

	public void getMovies() {
		try{
			String directorName="Tim MillerX";
			List<Movie> movieList=movieService.getMovies(directorName);
			System.out.println("Movie Name"+"\t\t"+"Director Name");
			System.out.println("**********"+"\t\t"+"*************");
			for(Movie m:movieList){
				System.out.println(m.getMovieName()+" \t\t"+m.getDirector().getDirectorName());
			}
			
			
		}catch(Exception e){
			System.out.println(environment.getProperty(e.getMessage()));
		}
	}

}