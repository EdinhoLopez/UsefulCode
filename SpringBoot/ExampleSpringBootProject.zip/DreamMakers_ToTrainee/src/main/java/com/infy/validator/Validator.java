package com.infy.validator;

import com.infy.model.Movie;

public class Validator {

	public static void validate(Movie movie) throws Exception {

		if(!validateMovie(movie)) {
			
			throw new Exception("Validator.INVALID_NAMES");
			
		}

	}

	public static Boolean validateMovie(Movie movie) throws Exception {

		return movie.getMovieName().matches("[a-zA-Z]+( [a-zA-z]*)") &&
			   movie.getDirector().getDirectorName().matches("[a-zA-Z]+( [a-zA-z]*)");
	}
}
