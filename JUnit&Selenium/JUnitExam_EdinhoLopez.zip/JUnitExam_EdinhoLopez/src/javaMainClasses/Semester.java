package javaMainClasses;

public interface Semester {

}