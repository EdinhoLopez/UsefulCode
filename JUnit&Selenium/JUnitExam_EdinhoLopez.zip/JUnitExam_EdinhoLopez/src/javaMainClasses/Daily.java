package javaMainClasses;

public interface Daily {

}
