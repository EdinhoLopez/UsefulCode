package javaMainClasses;

public class AdditionClass {

	public double addTwoNumbers(double num1, double num2) {
		return num1 + num2;
	}
}