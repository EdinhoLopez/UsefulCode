package javaMainClasses;

public interface Weekly {

}
