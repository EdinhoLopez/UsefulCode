package customeExceptions;

public class InvalidPasswordException extends IllegalArgumentException {
	private static final long serialVersionUID = 1L;
	/*There are two constructors, a no-arg constructor
	and a constructor which accepts a string as
	a parameter*/
	public InvalidPasswordException() {
		super();
	}
	public InvalidPasswordException(String eMessage) {
		super(eMessage);
	}
}
