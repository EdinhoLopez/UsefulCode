package javaTests;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.BeforeClass;
import org.junit.Test;

import javaMainClasses.Product;

public class QuestionEightTests {

	public static Product testObject;
	
	@BeforeClass
	public static void setUpTestObject() {
		
		//Instantiates an object from an abstract class
		testObject = mock(Product.class);
		
	}
	
	//Test the getName() method
	@Test
	public void testGetName() {
	
		//When this method is called then return this value
		 when(testObject.getName()).thenReturn("Cheese");
		 
		 //Is the method returning the value I asked for correctly?
		 assertThat(testObject.getName(),is("Cheese"));
		
		
		
		
	}

}
