package javaTests;

import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import javaMainClasses.AdditionClass;
import javaMainClasses.User;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeThat;
import static org.junit.Assume.assumeTrue;

import java.util.Arrays;
import java.util.Collection;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

// Annotate class with @RunWith(Parameterized.class)
@RunWith(Parameterized.class)
public class QuestionSixParameterizedTests {
	// Declare atttibutes
	private static User additionClass;
	private Integer userId;
	private String name;
	private String password;
	private Double javaScore;
	private Double sqlScore;
	private Integer testSum;
	private Boolean InvalidInput;

	/* Create the constructor. The order of arguments in the parentheses
	 * determines the parameter position in the two-dimensional Object arrays.
	 * Parameter1 = argument num1, Parameter2 = argument num2,
	 * Parameter3 = argument testSum, Parameter4 = argument confirmation*/
	public QuestionSixParameterizedTests(Integer userId, String name, String password, Double javaScore, 
			Double sqlScore, Integer testSum, Boolean InvalidInput) {
		
		this.userId = userId;
		this.name = name;
		this.password = password;
		this.javaScore = javaScore;
		this.sqlScore = sqlScore;
		this.testSum = testSum;
		this.InvalidInput = InvalidInput;
		
	}

	/* Set up the parameters. The confirmation parameter is null and will
	 * be assigned in the actual test method depending on accuracy of
	 * the addition result. */
	@Parameters()
    public static Collection<Object[]> data() {
        return Arrays.asList(
                new Object[][] {
                		{ 1, "Mark", "Mark123456", 50.5, 90.5, 1, null },  
                		{ 2, "Mark", "Mark123456", 100.0, 95.0, 2, null },
                		{ 3, "Mark", "Mark123456", 50.5, 50.0, 0, null },
                		{ 4, "Mark", "Mark123456", 90.5, 90.5, 2, null},
                		{ 5, "Steve", "Mark123456", 5.0, 0.5, 0, null}
                		});
    }

    // Create the static class variable additionClass to run the test methods
    @BeforeClass
    public static void setUp() {
    	additionClass = new User();
    }

    // Run the test
    @Test
    public void additionClassTest() {

    	additionClass = new User(userId,name,password,javaScore,sqlScore);
    	Integer actual = additionClass.calculateCredits();
    	Integer expected = testSum;
    	
    	assertTrue(actual == expected);

    }
    
   
    
}
