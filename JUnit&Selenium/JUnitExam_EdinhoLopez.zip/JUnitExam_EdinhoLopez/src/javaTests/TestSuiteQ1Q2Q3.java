package javaTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ QuestionOneTests.class,
		QuestionTwoTests.class,
		QuestionThreeTests.class })

public class TestSuiteQ1Q2Q3 {

}