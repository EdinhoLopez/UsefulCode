package javaTests;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

public class QuestionOneTests {

	public static String testString;
	
	//Initialize string object we will be testing
	@BeforeClass
	public static void initializeString() {
		
		testString = new String("Per Scholas - 211 N Ervay St. #700 - Dallas, TX 75201");
		
	}
	//Test the length() method
	@Test
	public void testLength() {
		
		//Is the length given by the method correct?
		assertThat(testString.length(),is(53));
		
		assertTrue(testString.length()==53);
		
		assertFalse(testString.length()>100);
		
		
	}
	
	//Test the  equalsIgnoreCase() method
	@Test
	public void testEqualsIgnoreCase() {
		
		//Does the method actually ignore capital letters?
		assertTrue(testString.equalsIgnoreCase("PER SCHOLAS - 211 N ERVAY ST. #700 - DALLAS, TX 75201"));
		
		//Does the method actually ignore lowercase letters?
		assertTrue(testString.equalsIgnoreCase("per scholas - 211 n ervay st. #700 - dallas, tx 75201"));
		
		//What if we mix capital and lowercase?
		assertTrue(testString.equalsIgnoreCase("pEr sChOlAs - 211 N eRvAy sT. #700 - daLLaS, Tx 75201"));
		
	}

	//Test the contentEquals() method
	@Test
	public void testContentEquals() {
		
		StringBuilder expected = new StringBuilder("Per Scholas - 211 N Ervay St. #700 - Dallas, TX 75201");
		
		//Do the contents match?
		assertTrue(testString.contentEquals(expected));
		
		//Change expected so the two variables are different now
		expected.append("X");
		
		assertFalse(testString.contentEquals(expected));
		
	}

	//Test the charAt() method
	@Test
	public void testCharAt() {
			
		//Is the first character returned correct?
		assertThat(testString.charAt(0),is('P'));
		
		assertTrue(testString.charAt(4) == 'S');
		
		assertFalse(testString.charAt(50) == 'X');
		
	}
	
	//Test the contains() method
	@Test
	public void testContains() {
		
		//Does the method actually return the correct output?
		assertTrue(testString.contains("Per Scholas"));
		
		assertFalse(testString.contains("NotAWord"));
		
		//Is the method case sensitive as it should be?
		assertFalse(testString.contains("PER SCHOLAS"));
		
	}
	
	//Test the startsWith() method
	@Test
	public void testStartsWith() {
		
		//Does the string start with "Per"?
		assertTrue(testString.startsWith("Per"));
		
		assertFalse(testString.startsWith("75201"));
		
		assertNotNull(testString.startsWith("Per"));
		
	}

	//Test the startsWith(String, int) method
	@Test
	public void testStartsWithV2() {
		
		//After skipping 4 characters, does the word start like this?
		assertTrue(testString.startsWith("Scholas", 4));
		
		assertFalse(testString.startsWith("75301", 7));
		
	}

	//Test the endsWith() method
	@Test
	public void testEndsWith() {
		
		//Does it actually end with 75201?
		assertThat(testString.endsWith("75201"),is(true));
		
		assertFalse(testString.endsWith("Per Scholas"));
		
	}

	//Test the substring() method
	@Test
	public void testSubstring() {
		
		assertThat(testString.substring(0,3),allOf(is("Per"), not("Scholas")));
		
		//Does substring work well with other methods?
		assertTrue(testString.substring(0, 3).length() == 3);
		
	}
	
	//Test the toLowerCase() method
	@Test
	public void testToLowerCase() {
		
		String expected = "per scholas - 211 n ervay st. #700 - dallas, tx 75201";
		
		assertEquals(testString.toLowerCase(),expected);
		
		//Make sure both string dont match due to being case sensitive
		assertNotEquals(testString.toLowerCase(),expected.toUpperCase());
		
		
	}
	
	
}
;