package javaTests;

import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import javaMainClasses.Weekly;

@RunWith(Categories.class)
@Categories.IncludeCategory(Weekly.class)
@Suite.SuiteClasses({InstructorTests.class, SchoolTests.class, StudentTests.class})

public class Question10OnlyWeeklyTests {

}
