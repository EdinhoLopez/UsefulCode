package javaTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ SchoolTests.class,
		InstructorTests.class,
		StudentTests.class })

public class Question10AllTestsSuite {
	
	

}
