package javaTests;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeThat;
import static org.junit.Assume.assumeTrue;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Objects;

import org.junit.BeforeClass;
import org.junit.Test;

import customeExceptions.InvalidPasswordException;
import javaMainClasses.User;
import javaMainClasses.UserDAO;

public class QuestionNineTests {
	
	public static UserDAO testObject;
	public static Boolean dbConnected;
	
	@BeforeClass
	public static void setUpDatabase() {
		
		testObject = new UserDAO();
		
		Connection testCon = testObject.testConnection();
		
		if(Objects.nonNull(testCon)) {
			
			
			dbConnected = true;
			
			try {
				
				testObject.registerUser(new User(1,"Steve","Steve12345",55.0,90.0));
				testObject.registerUser(new User(2,"Maria","Maria12345",90.0,65.0));
				testObject.registerUser(new User(3,"Cool","Cool12345",55.0,5.0));
				testObject.registerUser(new User(4,"Mario","Mario12345",100.0,100.0));
				testObject.registerUser(new User(5,"Mark","Mark12345",0.0,56.0));
				
				
			} catch (Exception e) {
				
				System.out.println("Unable to insert test data into DB");
				
			}
			
			
		}
		else {
			
			dbConnected = false;
			
		}
		
		
	}

	//Test the registerUser() method
	@Test
	public void testRegisterUser() {
		
		assumeTrue(dbConnected);
		
		User testUser = new User(10,"Mike","Mike12345",56.0,65.5);
		
		try {
			
			//Insert the object into the database
			Integer testID = testObject.registerUser(testUser);
			
			//Is the object that was inserted in the database?
			assertThat(testObject.getUserById(10).getName(),is("Mike"));
			
			//Does the method return the correct ID assigned to the User?
			assertThat(testID, equalTo(10));
			
			
		} catch (Exception e) {
			
			System.out.println("Unable to insert User into DB");
			
		}
		
	}
	
	//Test the getUserById() method
	@Test
	public void testGetUser() {
		
		try {
			//Make sure the method does not return a null when given a valid ID
			assertNotNull(testObject.getUserById(1));
			
			//Make sure the first user is retrieved correctly
			assertThat(testObject.getUserById(1).getName(),startsWith("Ste"));
			
			//Make sure no other user information is retrieved
			assertThat(testObject.getUserById(1).getName(),allOf(not("Mike"),not("Maria"),not("Cool")));
			
		} catch (Exception e) {
			
			System.out.println("Unable to use Get method");
			
		}
		
	}
	
	//Test the updateUser() method
	@Test
	public void testUpdateUser() {
		
		
		User testUser = new User(1,"Steve","Steve12345",100.0,100.0);
		try {
			//Make sure you are able to update JavaScore from a given User
			Boolean updatedUser = testObject.updateUser(testUser);
			
			//Make sure the user was actually updated
			assertTrue(updatedUser);
			
			//Make sure the updated User has the correct scores
			assertThat(testObject.getUserById(1).getJavaScore(),allOf(is(100.0),not(55.0)));
			
			assertThat(testObject.getUserById(1).getSqlScore(),allOf(is(100.0),not(90.0)));
			
		} catch (Exception e) {
			
			System.out.println("Unable to use Update method");
			
		}
		
		
	}

	//Test the removeUser() method
	@Test
	public void testRemoveUser() {
		
		try {
			
			testObject.removeUserById(3);
			
			//Test that the object is no longer in the DB
			assertNull(testObject.getUserById(3));
			
			//Test that you are cannot update a removed object
			assertFalse(testObject.updateUser(new User(3,"Steve","Steve12345",0.0,0.0)));
			
		} catch (Exception e) {
			
			System.out.println("Unable to use Remove method");
			
		}
		
	}
	
}
