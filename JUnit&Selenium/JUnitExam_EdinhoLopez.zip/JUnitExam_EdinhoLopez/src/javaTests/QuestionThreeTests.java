package javaTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

public class QuestionThreeTests {

	public static Integer testInt;
	
	@BeforeClass
	public static void setUpTestInt() {
		
		testInt = new Integer(10);
		
	}
	
	@Test
	public void testToBinaryString() {
		
		System.out.println(testInt.toBinaryString(10));
		
		//Make sure that ToBinaryString() does not return a null
		assertNotNull(testInt.toBinaryString(10));
		
		//Make sure that the method return the correct string
		assertEquals(testInt.toBinaryString(10),"1010");
		
		assertFalse(testInt.toBinaryString(10).equals("1011"));
		
		//Make sure the string has an appropriate length based on the input
		assertTrue(testInt.toBinaryString(10000).length() > 4);
		
		
		
		
		
	}

	
	
	
}
