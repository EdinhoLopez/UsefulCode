package javaTests;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import static org.hamcrest.text.IsEqualIgnoringCase.equalToIgnoringCase;
import static org.hamcrest.text.IsEqualCompressingWhiteSpace.equalToCompressingWhiteSpace;
import static org.hamcrest.text.IsEmptyString.emptyString;
import static org.hamcrest.text.IsEmptyString.emptyOrNullString;

import static org.hamcrest.core.IsEqual.equalTo;

import static org.hamcrest.beans.HasProperty.hasProperty;
import static org.hamcrest.beans.HasPropertyWithValue.hasProperty;


import org.junit.BeforeClass;
import org.junit.Test;

import customeExceptions.InvalidPasswordException;
import javaMainClasses.ListMapClass;

public class QuestionFiveTests {

	public static ListMapClass testObject;
	
	@BeforeClass
	public static void setUpTestObject() {
		
		testObject = new ListMapClass();
		
	}
	
	//Test the cities() method within ListMapClass
	@Test
	public void testCities() {
		
		//Make sure only 6 cities are added by the method
		assertThat(testObject.cities().size(),allOf(is(6), not(0)));
		
		//Make sure the method added Dallas & Irving as a city
		assertThat(testObject.cities(),hasItems("Dallas","Irving"));
		
		//Make sure the list starts with Dallas first
		assertEquals(testObject.cities().get(0),"Dallas");
		
	}

	//Test the getUserList() method
	@Test
	public void testGetUserList() throws InvalidPasswordException {
		
		//Make sure getUserList() doesnt return a null
		assertNotNull(testObject.getUserList());
		
		//Make sure only 3 objects are present
		assertTrue(testObject.getUserList().size() == 3);
		
		//Make sure the first object has the name "John"
		//Checks for a value that is within an object
		assertThat(testObject.getUserList().get(0),hasProperty("name",equalToIgnoringCase("John")));
		
		//Make sure that the second object's password is correct
		assertThat(testObject.getUserList().get(1),hasProperty("password",equalToCompressingWhiteSpace("jane1234")));
		
	}

	//Test the getCoursesMap() method
	@Test
	public void testGetCoursesMap() {
		
		//Make sure there are only 4 elements
		assertTrue(testObject.getCoursesMap().size() == 4);
		
		//Make sure the first course is retrieved when providing the correct key
		assertThat(testObject.getCoursesMap().get("ASM"), containsString("Application Support"));
		
		//Make sure that giving a wrong key will return nothing
		assertNull(testObject.getCoursesMap().get("FalseInfo"));
		
	}

	//Test the getUserMap() method
	@Test
	public void testGetUserMap() throws InvalidPasswordException {
		
		//Make sure there are only 3 objects
		assertThat(testObject.getUserMap().size(),is(3));
		
		//Make sure that the right object is returned when given a key
		assertThat(testObject.getUserMap().get(11).getName(),equalToIgnoringCase("Jovita"));
		
		//Make sure that null is returned if an invalid key is put
		assertNull(testObject.getUserMap().get(1111));
		
	}
	
}
