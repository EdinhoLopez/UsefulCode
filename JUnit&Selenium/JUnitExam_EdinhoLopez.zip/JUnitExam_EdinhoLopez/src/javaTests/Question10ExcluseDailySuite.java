package javaTests;

import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import javaMainClasses.Daily;

@RunWith(Categories.class)
@Categories.ExcludeCategory(Daily.class)
@Suite.SuiteClasses({InstructorTests.class, SchoolTests.class, StudentTests.class})

public class Question10ExcluseDailySuite {

}
