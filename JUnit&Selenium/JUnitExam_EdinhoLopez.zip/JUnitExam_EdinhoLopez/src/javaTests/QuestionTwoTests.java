package javaTests;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class QuestionTwoTests {

	public static String testString;
	
	//Initialize string object we will be testing
	@BeforeClass
	public static void initializeString() {
		
		testString = new String("Per Scholas - 211 N Ervay St. #700 - Dallas, TX 75201");
		
	}
	
	//Test the split(reg exp) method
	@Test
	public void testSplit() {
		
		//Make sure split() does not give a null output
		assertNotNull(testString.split(" "));
		
		//Make sure split() gave back the 12 words from testString
		assertTrue(testString.split(" ").length == 12);
		
		//Make sure the first word given back is Per
		assertThat(testString.split(" ")[0],is("Per"));	
		
	}

	//Test the join(delim, array) method
	@Test
	public void testJoin() {
		
		//Make sure join() correctly adds the delimiter
		assertThat(testString.join(":", "09","12","2015"), is("09:12:2015"));
		
		assertFalse(testString.join(":", "09","12","2015").contentEquals("09122015"));
		
		//Make sure all string joined are kept
		assertTrue(testString.join(":", "09","12","2015").contains("12"));
		
	}
	
}
