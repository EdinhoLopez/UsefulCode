package javaTests;


import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import javaMainClasses.AddVaryingTypeCalculator;
import javaMainClasses.AdditionClass;
import javaMainClasses.User;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeThat;
import static org.junit.Assume.assumeTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import org.hamcrest.Matcher;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

// Annotate class with @RunWith(Parameterized.class)
@RunWith(Parameterized.class)
public class QuestionSevenParameterizedTests {
	// Declare atttibutes
	private static AddVaryingTypeCalculator additionClass;
	private List<Object> givenList;
	private Double expectedOutcome;
	private Class expectedEx;

		public QuestionSevenParameterizedTests(List<Object> givenList,Double expectedOutcome,Class expectedEx) {
			
			this.givenList = givenList;
			this.expectedOutcome = expectedOutcome;
			this.expectedEx = expectedEx;
			
		}
	
	@Parameters()
    public static Collection<Object[]> data() {
    	
    	ArrayList<Character> input = new ArrayList<Character>();
    	input.add(new Character('a'));
    	input.add(new Character('w'));
    	
        return Arrays.asList(
                new Object[][] {
                	
                		//List with only strings
                		{new ArrayList<Object>(Arrays.asList("3","4","5")),12.0,null},
                		
                		//List with only int
                		{new ArrayList<Object>(Arrays.asList(3,7,5)),15.0, null},
                		
                		//List with only doubles
                		{new ArrayList<Object>(Arrays.asList(3.5,4.5,4.5)),12.5, null},
                		
                		//List that is a mix of all three
                		{new ArrayList<Object>(Arrays.asList(1,"5",4.5,1.5)),12.0, null},
                		
                		//List that throws an IllegalArgumentExpression
                		{input,12.0, IllegalArgumentException.class},
                		
                		//List that throws an IllegalArgumentExpression
                		{new ArrayList<Object>(Arrays.asList("asdf","asdf")),12.0, IllegalArgumentException.class}
                		
                		});
    }

  
    @BeforeClass
    public static void setUp() {
    	additionClass = new AddVaryingTypeCalculator();
    }

    @Rule
	public ExpectedException ee = ExpectedException.none();
    
    @Test
    public void TypeCalculatorTest() {
    	
    	if(Objects.nonNull(expectedEx)) {
    		
    		ee.expect(expectedEx);
    		
    	}

    	Double actual = additionClass.addTwoNumbersVaryingType(givenList);
    	Double expected = expectedOutcome;
    	
    	assertTrue(actual.equals(expected));

    }
    
   
    
}