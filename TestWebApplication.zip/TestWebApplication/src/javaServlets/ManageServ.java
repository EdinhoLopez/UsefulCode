package javaServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ManageServ")
public class ManageServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
 

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
		
		if (request.getParameter("log") != null) {
			
			System.out.println("Hello");
			
			Cookie[] cookies = request.getCookies();

			if (cookies != null) {
			 for (Cookie cookie : cookies) {
			   if (cookie.getName().equals("userName")) {
			     
				   System.out.println(cookie.getName());
				   System.out.println("not ok: " + cookie.getValue());
				   
				   
			    }
			  }
			}
			
			String logUsername = request.getParameter("UsernameLog");
			
			String logPass = request.getParameter("PasswordLog");
			
			
			

			
			}
	}

}
