package com.perscholas.rest_controller.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan("com.perscholas.rest_controller")
public class RootAppConfig {
	
}