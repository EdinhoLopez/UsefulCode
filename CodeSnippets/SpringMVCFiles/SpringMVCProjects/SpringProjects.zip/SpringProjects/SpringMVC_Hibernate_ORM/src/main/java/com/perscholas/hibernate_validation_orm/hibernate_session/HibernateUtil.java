package com.perscholas.hibernate_validation_orm.hibernate_session;

import org.hibernate.SessionFactory;

public interface HibernateUtil {
	SessionFactory getSessionFactory();
}